package com.springbootassgn.service;

import com.springbootassgn.model.Address;
import com.springbootassgn.model.Employee;

public interface EmployeeService {
	public Integer addEmployee(Employee employee) throws Exception;
	public void updateEmployee(Integer id, Address address) throws Exception;
	public void deleteEmployee(Integer id) throws Exception;
}
