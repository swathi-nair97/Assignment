package com.springbootassgn.dao;

import com.springbootassgn.model.Address;
import com.springbootassgn.model.Employee;

public interface EmployeeDAO {
	public Integer addEmployee(Employee employee);
	public void updateEmployee(Integer id, Address address);
	public void deleteEmployee(Integer id);
}
